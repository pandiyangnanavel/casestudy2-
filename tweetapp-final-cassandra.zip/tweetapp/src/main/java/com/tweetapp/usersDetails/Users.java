package com.tweetapp.usersDetails;

import java.util.UUID;

import org.springframework.data.annotation.Id;
import org.springframework.data.cassandra.core.cql.Ordering;
import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.CassandraType;
import org.springframework.data.cassandra.core.mapping.CassandraType.Name;
import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;
import org.springframework.data.cassandra.core.mapping.Table;

import com.datastax.oss.driver.api.core.uuid.Uuids;

@Table(value = "users_by_user_id")
public class Users {
	
	@Id @PrimaryKeyColumn(name = "login_id", ordinal = 0, type = PrimaryKeyType.PARTITIONED)
	private String loginId;
	
	@PrimaryKeyColumn(type = PrimaryKeyType.CLUSTERED, ordering = Ordering.DESCENDING)
    @CassandraType(type = Name.TIMEUUID)
    private UUID timeUuid;
	
	@PrimaryKeyColumn(name = "email_id",type = PrimaryKeyType.CLUSTERED, ordering = Ordering.ASCENDING)
    @CassandraType(type = Name.TEXT)
	private String email;
	
	@Column("first_name")
    @CassandraType(type = Name.TEXT)
	private String firstName;
	
	@Column("last_name")
    @CassandraType(type = Name.TEXT)
	private String lastName;
	
	@Column("password")
    @CassandraType(type = Name.TEXT)
	private String password;
	
	@Column("contact_no")
    @CassandraType(type = Name.TEXT)
	private String contactNumber;
	

	public Users() {
		this.timeUuid = Uuids.timeBased();
	}

	public UUID getTimeUuid() {
		return timeUuid;
	}

	public void setTimeUuid(UUID timeUuid) {
		this.timeUuid = timeUuid;
	}

	public Users(String loginId, UUID timeUuid, String email, String firstName, String lastName,
			String password, String contactNumber) {
		super();
		this.loginId = loginId;
		this.timeUuid = timeUuid;
		this.email = email;
		this.firstName = firstName;
		this.lastName = lastName;
		this.password = password;
		this.contactNumber = contactNumber;
	}

	
	public String getFirstName() {
		return firstName;
	}



	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}



	public String getLastName() {
		return lastName;
	}



	public void setLastName(String lastName) {
		this.lastName = lastName;
	}



	public String getEmail() {
		return email;
	}



	public void setEmail(String email) {
		this.email = email;
	}



	public String getLoginId() {
		return loginId;
	}



	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}



	public String getPassword() {
		return password;
	}



	public void setPassword(String password) {
		this.password = password;
	}



	public String getContactNumber() {
		return contactNumber;
	}



	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	@Override
	public String toString() {
		return "Users [loginId=" + loginId + ", timeUuid=" + timeUuid + ", email=" + email
				+ ", firstName=" + firstName + ", lastName=" + lastName + ", password=" + password + ", contactNumber="
				+ contactNumber + "]";
	}

	
}
