package com.tweetapp.comments;

import java.util.Date;

import org.springframework.data.cassandra.core.mapping.CassandraType;
import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;
import org.springframework.data.cassandra.core.mapping.CassandraType.Name;

import com.tweetapp.tweet.TweetKey;

@Table("comments_by_tweet_id")
public class Comments {
	
	@PrimaryKey
	private TweetKey key;
	
	@Column("comments")
    @CassandraType(type = Name.TEXT)
	private String comment;
	
	@Column("comment_date")
    @CassandraType(type = Name.DATE)
	private Date date;
	
	public Comments() {
	}
	

	public Comments(String comment, Date date) {
		super();
		this.comment = comment;
		this.date = date;
	}



	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}


	public TweetKey getKey() {
		return key;
	}


	public void setKey(TweetKey key) {
		this.key = key;
	}


	@Override
	public String toString() {
		return "Comments [comment=" + comment + ", tweetId=" + key.getId() + ", date=" + date + ", loginId=" + key.getLoginId()
				+ "]";
	}


	
}
