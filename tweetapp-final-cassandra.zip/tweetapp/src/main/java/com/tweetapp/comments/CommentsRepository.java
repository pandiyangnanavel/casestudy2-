package com.tweetapp.comments;

import java.util.List;

import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.stereotype.Repository;

import com.tweetapp.tweet.TweetKey;

@Repository
public interface CommentsRepository extends CassandraRepository<Comments, TweetKey> {
	
	List<Comments> getAllByKey_Id(long tweetId);
}
