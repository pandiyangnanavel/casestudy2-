package com.tweetapp.likes;


import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface LikesRepository extends CassandraRepository<Likes, Long> {
	
	Likes getLikeById(long id);
	
	Likes deleteById(long id);

}
