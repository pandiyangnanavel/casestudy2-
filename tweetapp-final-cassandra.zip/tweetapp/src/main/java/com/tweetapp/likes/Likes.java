package com.tweetapp.likes;

import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("likes_by_likes_id")
public class Likes {
	
	@PrimaryKeyColumn(name = "likes_id", type = PrimaryKeyType.PARTITIONED)
	private long id;
	@Column
	private long likes;
	
	
	public Likes() {
	}




	public Likes(long id, long likes) {
		super();
		this.id = id;
		this.likes = likes;
	}




	public long getId() {
		return id;
	}


	public void setId(long id) {
		this.id = id;
	}


	public long getLikes() {
		return likes;
	}


	public void setLikes(long likes) {
		this.likes = likes;
	}




	@Override
	public String toString() {
		return "Likes [id=" + id + ", likes=" + likes + "]";
	}
	
	





	

}
