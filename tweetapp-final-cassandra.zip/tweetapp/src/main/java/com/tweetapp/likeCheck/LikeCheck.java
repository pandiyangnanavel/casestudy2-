package com.tweetapp.likeCheck;

import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("likes_check_by_id")
public class LikeCheck {

	@PrimaryKeyColumn(name = "likes_check_id", type = PrimaryKeyType.PARTITIONED)
	private long id;

	@Column
	private String loginId;
	@Column
	private long tweetId;

	public LikeCheck(long id, String loginId, long tweetId) {
		super();
		this.id = id;
		this.loginId = loginId;
		this.tweetId = tweetId;
	}

	public LikeCheck() {
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getLoginId() {
		return loginId;
	}

	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}

	public long getTweetId() {
		return tweetId;
	}

	public void setTweetId(long tweetId) {
		this.tweetId = tweetId;
	}

	@Override
	public String toString() {
		return "LikeCheck [loginId=" + loginId + ", tweetId=" + tweetId + "]";
	}

}
