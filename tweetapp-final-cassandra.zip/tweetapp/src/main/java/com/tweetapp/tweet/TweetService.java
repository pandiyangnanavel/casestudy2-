package com.tweetapp.tweet;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TweetService {
	
	@Autowired
	private TweetRepository tweetRepository;
	
	private static int idCounter=0;
	
	public Tweet find(long id) {
		return tweetRepository.getByKey_Id(id);
	}
	
	public List<Tweet> findAll(){
		return tweetRepository.findAll();
	}
	
	public List<Tweet> findByLoginId(String loginId){
		return tweetRepository.findByKey_loginId(loginId);
	}
	
	public Tweet postTweets(Tweet t) {
		return tweetRepository.save(t);
	}
	
	public Tweet updateTweets(Tweet t) {
		if(t.getKey().getId()==-1) {
			t.getKey().setId(idCounter++);
			return postTweets(t);
		}
		
		else {
			return tweetRepository.save(t);
		}
		
	}
	
	public void deleteTweet(long id) {
		tweetRepository.deleteById(id);
	}
	
	public Tweet updateTweet(long id, Tweet tweet) {
		tweetRepository.deleteById(id);
		
		Tweet updatedTweet = tweetRepository.save(tweet);
		
		return updatedTweet;
	}

}
