package com.tweetapp.tweet;

import java.util.Date;

import org.springframework.data.cassandra.core.mapping.CassandraType;
import org.springframework.data.cassandra.core.mapping.CassandraType.Name;
import org.springframework.data.cassandra.core.mapping.Column;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

@Table("tweets_by_login_id")
public class Tweet {
	
	@PrimaryKey
    private TweetKey key;
	
	@Column("tweets")
    @CassandraType(type = Name.TEXT)
	private String tweets;
	
	@Column("tweet_date")
    @CassandraType(type = Name.DATE)
	private Date date;
	
	public Tweet() {}
	
	public Tweet(TweetKey key, String loginId, String tweets, Date date) {
		super();
		this.key = key;
		this.tweets = tweets;
		this.date = date;
	}

	public TweetKey getKey() {
		return key;
	}

	public void setId(TweetKey key) {
		this.key = key;
	}


	public String getTweets() {
		return tweets;
	}

	public void setTweets(String tweets) {
		this.tweets = tweets;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	@Override
	public String toString() {
		return "Tweet [id=" + key.getId() + ", loginId=" + key.getLoginId() + ", timeUuid=" + key.getTimeUuid() + ", tweets=" + tweets + ", date=" + date + "]";
	}
	
	
	

}
