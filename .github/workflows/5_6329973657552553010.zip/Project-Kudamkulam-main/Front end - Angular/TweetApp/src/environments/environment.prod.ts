export const environment = {
  production: true,
  // servername: 'http://ec2-52-66-238-7.ap-south-1.compute.amazonaws.com:8080'
  servername: 'http://localhost:8080'
};
