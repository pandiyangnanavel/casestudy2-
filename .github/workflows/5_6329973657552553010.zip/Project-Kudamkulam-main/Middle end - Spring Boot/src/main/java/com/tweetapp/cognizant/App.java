package com.tweetapp.cognizant;


/**
 * TweetApp
 *
 */
public class App 
{
	
	
    public static void main( String[] args )
    {
    	Menu.runApplication();
    }
}
