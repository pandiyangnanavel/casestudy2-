# tweetapp
This is a spring boot based project with a simple functionality of tweet app.
