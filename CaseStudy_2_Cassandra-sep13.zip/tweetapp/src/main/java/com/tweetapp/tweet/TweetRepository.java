package com.tweetapp.tweet;

import java.util.List;

import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TweetRepository extends CassandraRepository<Tweet, Long>{
	
	List<Tweet> findByKey_loginId(String loginId);
	
//	@Query(value="{'id' : ?0}", delete=true)
//	Tweet DeleteById(String id);
	
	Tweet getByKey_Id(long id);

}
