package com.tweetapp.tweet;

import org.springframework.data.cassandra.core.cql.Ordering;
import org.springframework.data.cassandra.core.cql.PrimaryKeyType;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyClass;
import org.springframework.data.cassandra.core.mapping.PrimaryKeyColumn;

@PrimaryKeyClass
public class TweetKey {
	
	@PrimaryKeyColumn(name = "tweet_id", ordinal = 0, type = PrimaryKeyType.PARTITIONED)
	private long id;
	
	@PrimaryKeyColumn(name = "login_id", ordinal = 1, type = PrimaryKeyType.CLUSTERED,ordering = Ordering.ASCENDING)
	private String loginId;
	
	/*
	 * @PrimaryKeyColumn(ordinal = 2,type = PrimaryKeyType.CLUSTERED, ordering =
	 * Ordering.DESCENDING)
	 * 
	 * @CassandraType(type = Name.TIMEUUID) private UUID timeUuid;
	 */

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getLoginId() {
		return loginId;
	}

	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}
	
}
